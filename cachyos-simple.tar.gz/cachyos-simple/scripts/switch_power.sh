#!/bin/bash
# Power Profile Manager - Automatic switching between power profiles
# Integrates with udev to detect charger connection/disconnection

POWER_SUPPLY_PATH="/sys/class/power_supply/ACAD/online"
LOG_FILE="/var/log/power-profile-switch.log"

# Function to log events
log_event() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# Function to set power profile
set_power_profile() {
    local profile=$1
    if command -v powerprofilesctl &> /dev/null; then
        powerprofilesctl set "$profile"
        log_event "Switched to $profile profile"
        echo "Power profile changed to: $profile"
    else
        log_event "ERROR: powerprofilesctl not found"
    fi
}

# Check if power adapter is connected
if [ -f "$POWER_SUPPLY_PATH" ]; then
    ac_status=$(cat "$POWER_SUPPLY_PATH")
    
    if [ "$ac_status" = "1" ]; then
        # AC connected - use balanced profile for performance
        set_power_profile "balanced"
        log_event "AC adapter connected"
    elif [ "$ac_status" = "0" ]; then
        # AC disconnected - use power-saver for battery life
        set_power_profile "power-saver"
        log_event "AC adapter disconnected - battery mode activated"
    fi
else
    log_event "ERROR: Power supply path not found at $POWER_SUPPLY_PATH"
    exit 1
fi
